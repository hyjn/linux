#include "bookwindow.h"
#include "ui_bookwindow.h"
#include <QMessageBox>
#include <QFileDialog>
#include <QSqlQueryModel>
#include <QTableView>
#include <QSqlRecord>
#include <QSqlTableModel>
#include <windows.h>
Bookwindow::Bookwindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Bookwindow)
{
    ui->setupUi(this);
    InitNull();
    Init();
}

Bookwindow::~Bookwindow()
{
    delete ui;
}

//界面初始化函数
void Bookwindow::Init()
{
    setLetter();        //文学
    setNovel();         //小说
    setBiograthy();     //传记
    setPsychic();       //心理学
    setLaw();           //法律
}
//界面初始化置空
void Bookwindow::InitNull()
{
    v1 = NULL;      //布局为空
    v2 = NULL;
    v3 = NULL;
    v4 = NULL;
    v5 = NULL;
}
//文学
void Bookwindow::setLetter()
{
    if(v1 != NULL){
        delete v1;
        v1 = NULL;
    }
    for(int i = 0;i < vect1.size();i++){
        delete vect1[i];    //在此处i表示的是QVector中存放书的数量
    }
    vect1.clear();
    v1 = new QVBoxLayout(ui->scrollWidget_1);   //ui->scrollWidget_1添加到垂直布局中
    QSqlQuery query;
    query.exec("select * from bookinfo");
    while(query.next()) //读取下一条记录
    {
        if(query.value(6).toInt() == 1) //query.value(6).toInt() == 1;
        {
            BookWidget *book = new BookWidget;
            book->setWidget(query.value(4).toString(),
                            query.value(1).toString(),
                            query.value(2).toString(),
                            query.value(3).toString(),
                            query.value(5).toString());
            v1->addWidget(book);
            vect1.append(book);
        }
    }
}
//小说
void Bookwindow::setNovel()
{
    if(v2 != NULL){
        delete v2;
        v2 = NULL;
    }
    for(int i = 0;i < vect2.size();i++){
        delete vect2[i];
    }
    vect2.clear();
    v2 = new QVBoxLayout(ui->scrollWidget_2);
    QSqlQuery query;
    query.exec("select * from bookinfo");
    while(query.next())
    {
        if(query.value(6).toInt() == 2)
        {
            BookWidget *book = new BookWidget;
            book->setWidget(query.value(4).toString(),
                            query.value(1).toString(),
                            query.value(2).toString(),
                            query.value(3).toString(),
                            query.value(5).toString());
            v2->addWidget(book);
            vect2.append(book);
        }
    }
}
//传记
void Bookwindow::setBiograthy()
{
    if(v3 != NULL){
        delete v3;
        v3 = NULL;
    }
    for(int i = 0;i < vect3.size();i++){
        delete vect3[i];
    }
    vect3.clear();
    v3 = new QVBoxLayout(ui->scrollWidget_3);
    QSqlQuery query;
    query.exec("select * from bookinfo");
    while(query.next())
    {
        if(query.value(6).toInt() == 3)
        {
            BookWidget *book = new BookWidget;
            book->setWidget(query.value(4).toString(),
                            query.value(1).toString(),
                            query.value(2).toString(),
                            query.value(3).toString(),
                            query.value(5).toString());
            v3->addWidget(book);
            vect3.append(book);
        }
    }
}
//心理学
void Bookwindow::setPsychic()
{
    if(v4 != NULL){
        delete v4;
        v4 = NULL;
    }
    for(int i = 0;i < vect4.size();i++){
        delete vect4[i];
    }
    vect4.clear();
    v4 = new QVBoxLayout(ui->scrollWidget_4);
    QSqlQuery query;
    query.exec("select * from bookinfo");
    while(query.next())
    {
        if(query.value(6).toInt() == 4)
        {
            BookWidget *book = new BookWidget;
            book->setWidget(query.value(4).toString(),
                            query.value(1).toString(),
                            query.value(2).toString(),
                            query.value(3).toString(),
                            query.value(5).toString());
            v4->addWidget(book);
            vect4.append(book);
        }
    }
}
//法学
void Bookwindow::setLaw()
{
    if(v5 != NULL){
        delete v5;
        v5 = NULL;
    }
    for(int i = 0;i < vect5.size();i++){
        delete vect5[i];
    }
    vect5.clear();
    v5 = new QVBoxLayout(ui->scrollWidget_5);
    QSqlQuery query;
    query.exec("select * from bookinfo");
    while(query.next())
    {
        if(query.value(6).toInt() == 5)
        {
            BookWidget *book = new BookWidget;
            book->setWidget(query.value(4).toString(),
                            query.value(1).toString(),
                            query.value(2).toString(),
                            query.value(3).toString(),
                            query.value(5).toString());
            v5->addWidget(book);//添加到垂直布局中
            vect5.append(book); //追加至容器类
        }
    }
}
//删除图书 确定
void Bookwindow::on_deleteOkBtn_clicked()
{
    QString name = ui -> deleteNameLine -> text();
    QSqlQuery query;
    QString cmd = tr("delete from bookinfo where Book_Name = '%1'").arg(name);
    if(query.exec(cmd)){
        QMessageBox::information(this,"提示信息","删除成功",QMessageBox::Ok);
        ui -> deleteNameLine -> clear();
        Init();
    }
}
//删除图书 取消
void Bookwindow::on_deleteNoBtn_clicked()
{
    ui -> deleteNameLine -> clear();
}
//增加图书 确定
void Bookwindow::on_addOkBtn_clicked()
{
    QString BookName,AutName;
    double Price;
    int Num,Type,Id;    //Id标识的是图书的编号
    BookName = ui->addNmaeLine->text();
    AutName = ui ->addAutLine->text();
    Price = ui -> addPriLine->text().toDouble();
    Num = ui -> addNumLine->text().toInt();
    //类型
    if(ui->addComBoxLine->currentText() == "文学类")
    {
        Type = 1;
    }else if(ui -> addComBoxLine -> currentText() == "小说类"){
        Type = 2;
    }else if(ui -> addComBoxLine -> currentText() == "传记类"){
        Type = 3;
    }else if(ui -> addComBoxLine -> currentText() == "心理学"){
        Type = 4;
    }else if(ui -> addComBoxLine -> currentText() == "法学类"){
        Type = 5;
    };
    QSqlQuery query;
    query.exec("select count(*) from bookinfo");
    while(query.next()){
        Id = query.value(0).toInt()+1;
    }
    //数据库操作
    QString cmd = tr("insert into bookinfo values(%1,'%2','%3',%4,'%5',%6,%7)").arg(Id).arg(BookName).arg(AutName).arg(Price).arg(this->PicPath).arg(Num).arg(Type);
    if(query.exec(cmd)){
        QMessageBox::information(this,"提示信息","上架成功",QMessageBox::Ok);
        ui->addAutLine->clear();
        ui->addNmaeLine->clear();
        ui->addNumLine->clear();
        ui->addPriLine->clear();
        ui->addPicLaBel->clear();
        Init();
    }
}
//获取图片路径
void Bookwindow::on_addPicBtn_clicked()
{
    this -> PicPath = QFileDialog::getOpenFileName(this,"获取图片","/","*.jpg;;*.png");
    ui->addPicLaBel->setPixmap(QPixmap(this->PicPath));
}
//修改确定
void Bookwindow::on_updateOkBtn_clicked()
{
    //    ui->updatePictureBtn->setEnabled(false);
    QString tmp = ui->updateSourceLine->text();
    QString temp = ui->updateNEewLine->text();
    QSqlQuery query;
    QString cmd;
    if(ui->updatecomboBox->currentText() == "书名"){
        cmd = tr("update bookinfo set Book_Name = '%1' where Book_Name = '%2'").arg(temp).arg(tmp);
        query.exec(cmd);
    }else if(ui->updatecomboBox->currentText() == "作者"){
        cmd = tr("update bookinfo set Book_Author = '%1' where Book_Author = '%2'").arg(temp).arg(tmp);
        query.exec(cmd);
    }else if(ui->updatecomboBox->currentText() == "价格"){
        cmd = tr("update bookinfo set Book_Price = %1 where Book_Price = '%2'").arg(temp).arg(tmp);
        query.exec(cmd);
    }else if(ui->updatecomboBox->currentText() == "库存"){
        cmd = tr("update bookinfo set Book_Number = %1 where Book_Number = '%2'").arg(temp).arg(tmp);
        query.exec(cmd);
    }else if(ui->updatecomboBox->currentText() == "图片"){
        cmd = tr("update bookinfo set Book_Picture = '%1' where Book_Picture = '%2'").arg(this->PicPath).arg(tmp);
        query.exec(cmd);
    }else if(ui->updatecomboBox->currentText() == "类别"){
        cmd = tr("update bookinfo set Book_Type = %1 where Book_Type = '%2'").arg(temp).arg(tmp);
        query.exec(cmd);
    }
    if(query.exec(cmd)){
        QMessageBox::information(this,"提示信息","修改成功",QMessageBox::Ok);
        ui->updateSourceLine->clear();
        ui->updateNEewLine->clear();
        ui->updatePicture->clear();
    }
}
//修改 图片
void Bookwindow::on_updatePictureBtn_clicked()
{
    this -> PicPath = QFileDialog::getOpenFileName(this,"获取图片","/","*.jpg;;*.png");
    ui-> updatePicture -> setPixmap(QPixmap(this->PicPath));
}
// 查询 图书
void Bookwindow::on_selectOkBtn_clicked()
{
    QString temp = ui->selectLine->text();
    QSqlQuery query;
    QSqlQueryModel *model = new QSqlQueryModel;
    ui->tableView->setModel(model); //此句必须在前,才能进行表格属性的设置
    ui->tableView->horizontalHeader()->setDefaultAlignment(Qt::AlignHCenter);//表头信息居中
    model->setQuery("select * from bookinfo");
    model->sort(0,Qt::AscendingOrder);
    model->setHeaderData(0,Qt::Horizontal,tr("书名"));
    model->setHeaderData(1,Qt::Horizontal,tr("作者"));
    model->setHeaderData(2,Qt::Horizontal,tr("价格"));
    model->setHeaderData(3,Qt::Horizontal,tr("库存"));
    model->setHeaderData(4,Qt::Horizontal,tr("类型"));

//    model->data(model->index(10,5),Qt::TextAlignmentRole);

    QString cmd;
    if(ui->selectcomboBox->currentText() == "书名"){
        cmd = tr("select Book_Name,Book_Author,Book_Price,Book_Number,Book_Type from bookinfo where Book_Name = '%1'").arg(temp);
    }else if(ui->selectcomboBox->currentText() == "作者"){
        cmd = tr("select Book_Name,Book_Author,Book_Price,Book_Number,Book_Type from bookinfo where Book_Author = '%1'").arg(temp);
    }else if(ui->selectcomboBox->currentText() == "价格"){
        cmd = tr("select Book_Name,Book_Author,Book_Price,Book_Number,Book_Type from bookinfo where Book_Price = %1").arg(temp.toDouble());
    }else if(ui->selectcomboBox->currentText() == "库存"){
        cmd = tr("select Book_Name,Book_Author,Book_Price,Book_Number,Book_Type from bookinfo where Book_Number = %1").arg(temp.toInt());
    }else if(ui->selectcomboBox->currentText() == "类型"){
        cmd = tr("select Book_Name,Book_Author,Book_Price,Book_Number,Book_Type from bookinfo where Book_Type = %1").arg(temp.toInt());
    }
    if(query.exec(cmd)){
        model->setQuery(cmd);       //将查询结果返回至表格中
        QMessageBox::information(this,"提示消息","查询成功",QMessageBox::Ok);
        ui->selectLine->clear();    //清空消息框
    }
}
//查询图书 取消
void Bookwindow::on_selectNoBtn_clicked()
{
    ui->selectLine->clear();        //清空消息框
    QSqlQueryModel *model = new QSqlQueryModel;
    ui->tableView->setModel(model);//设置表格属性
}
