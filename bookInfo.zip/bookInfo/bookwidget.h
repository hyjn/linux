#ifndef BOOKWIDGET_H
#define BOOKWIDGET_H

#include <QWidget>
#include <QPaintEvent>
#include <QPainter>

namespace Ui {
class BookWidget;
}

class BookWidget : public QWidget
{
    Q_OBJECT

public:
    explicit BookWidget(QWidget *parent = 0);
    ~BookWidget();
    void setWidget(QString pic,QString name,QString aut,QString pri,QString num);

protected:
    void paintEvent(QPaintEvent *); //绘图事件

private:
    Ui::BookWidget *ui;
};

#endif // BOOKWIDGET_H
