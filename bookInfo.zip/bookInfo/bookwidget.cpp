#include "bookwidget.h"
#include "ui_bookwidget.h"

BookWidget::BookWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BookWidget)
{
    ui->setupUi(this);
}

BookWidget::~BookWidget()
{
    delete ui;
}

void BookWidget::setWidget(QString pic, QString name, QString aut,QString pri, QString num)
{
    ui -> label_pic -> setPixmap(QPixmap(pic));     //设置图片
    ui -> label_name -> setText(name);              //设置图书名称
    ui -> label_aut -> setText(aut);                //设置作者名
    ui -> label_pri -> setText(pri);                //设置图书价格
    ui -> label_num -> setText(num);                //设置图书数量
}
//为当前部件添加背景
void BookWidget::paintEvent(QPaintEvent *)
{
    QImage image;
    image.load(":/image/背景8.jpg");  //加载图片
    QPainter painter(this);          //将当前部件设置到绘图部件中
    QRect source(0,0,image.width(),image.height()); //源图片大小
    QRect target(0,0,this->width(),this->height()); //目标图片大小,即当前部件大小

    painter.drawImage(target,image,source);     //调用画图事件
}
