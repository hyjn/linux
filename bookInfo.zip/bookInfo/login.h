#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include <QMessageBox>
#include <QSqlDatabase>
#include "bookwindow.h"

namespace Ui {
class Login;
}

class Login : public QWidget
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = 0);
    ~Login();
    void sqlinit(); //数据库初始化

private slots:
    void on_registerbtn_2_clicked();    //注册

    void on_loginbtn_2_clicked();       //登录

    void on_cancelbtn_3_clicked();      //取消

    void on_okbtn_2_clicked();          //确定

private:
    Ui::Login *ui;
    QSqlDatabase db;
    Bookwindow *b;
};

#endif // LOGIN_H
