#ifndef BOOKWINDOW_H
#define BOOKWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>   //水平布局
#include <QHBoxLayout>   //垂直布局
#include <QDebug>        //调试
#include <QSqlDatabase>  //数据库头文件
#include <QSqlQuery>     //数据库查询

#include "bookwidget.h"

namespace Ui {
class Bookwindow;
}

class Bookwindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit Bookwindow(QWidget *parent = 0);
    ~Bookwindow();
    void Init();        //界面初始化
    void InitNull();    //界面置空

    void setLetter();    //文学
    void setNovel();     //小说
    void setBiograthy(); //传记
    void setPsychic();   //心理学
    void setLaw();       //法律

private slots:
    void on_deleteOkBtn_clicked();

    void on_deleteNoBtn_clicked();

    void on_addOkBtn_clicked();

    void on_addPicBtn_clicked();

    void on_updateOkBtn_clicked();

    void on_updatePictureBtn_clicked();

    void on_selectOkBtn_clicked();

    void on_selectNoBtn_clicked();

private:
    Ui::Bookwindow *ui;
    QSqlDatabase db;
    QVBoxLayout *v1;
    QVBoxLayout *v2;
    QVBoxLayout *v3;
    QVBoxLayout *v4;
    QVBoxLayout *v5;
    QString PicPath;
    QVector<BookWidget*> vect1;
    QVector<BookWidget*> vect2;
    QVector<BookWidget*> vect3;
    QVector<BookWidget*> vect4;
    QVector<BookWidget*> vect5;
};

#endif // BOOKWINDOW_H
