#include "login.h"
#include "ui_login.h"
#include "bookwidget.h"
#include <QDebug>
#include <QApplication>

Login::Login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Login)
{
    ui -> setupUi(this);
    ui -> stackedWidget->setCurrentIndex(0);  //设置现在的索引值,切换到登录
    ui -> passwdLine_2 -> setEchoMode(QLineEdit::Password);
    ui -> passwdLine_3 -> setEchoMode(QLineEdit::Password);
    ui -> qrpasswdLine_3 -> setEchoMode(QLineEdit::Password);
    sqlinit();
}

Login::~Login()
{
    delete ui;
}
//初始化数据库
void Login::sqlinit()
{
    db = QSqlDatabase::addDatabase("QMYSQL");   //新增数据库
    db.setHostName("127.0.0.1");                //设置主机地址
    db.setPort(3306);                           //设置端口号
    db.setDatabaseName("book");                 //设置数据库名称
    db.setUserName("root");                     //初始化用户名
    db.setPassword("root");                     //初始化用户密码
    db.open();                                  //打开数据库
}
//注册
void Login::on_registerbtn_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);

}
//取消
void Login::on_cancelbtn_3_clicked()
{
    ui -> nameLine_3 -> clear();
    ui -> passwdLine_3 -> clear();
    ui -> qrpasswdLine_3 -> clear();
    ui -> yzpasswdLine_3 -> clear();
    ui->stackedWidget->setCurrentIndex(0);
}
//确定
void Login::on_okbtn_2_clicked()
{
    QString name,passwd1,passwd2,adminnum;
    name = ui -> nameLine_3 -> text();
    passwd1 = ui -> passwdLine_3 -> text();
    passwd2 = ui -> qrpasswdLine_3 -> text();
    adminnum = ui -> yzpasswdLine_3 -> text();
    if(name == "" || passwd1 == "" || passwd2 == "" || adminnum == ""){
        QMessageBox::information(this,"提示信息","数据不能为空",QMessageBox::Ok);
    }else if(passwd1 != passwd2){
        QMessageBox::information(this,"提示信息","两次密码不符",QMessageBox::Ok);
    }else if(adminnum != "admin"){
        QMessageBox::information(this,"提示信息","验证码不正确",QMessageBox::Ok);
    }else{
        QSqlQuery query;
        QString byte = QString("insert into useinfo values('%1','%2')").arg(name).arg(passwd1);
        query.exec(byte);
        ui->stackedWidget->setCurrentIndex(0);
    }
}
//登录
void Login::on_loginbtn_2_clicked()
{
    QString name1,passwd1;
    name1 = ui -> nameLine_2 -> text();
    passwd1 = ui -> passwdLine_2 -> text();
    QSqlQuery query;
    query.exec("select * from useinfo");
    while(query.next()){    //query.next()查询的是下一条信息
        if(name1 == query.value(0).toString() && passwd1 == query.value(1).toString() && name1 != "" && passwd1 != ""){
            b = new Bookwindow; //动态分配内存
            b->show();
            this->hide();
            return;
        }
    }
    //没有查询到信息,弹出消息框,并清空内容
    QMessageBox::information(this,"提示信息","用户名或密码有误",QMessageBox::Ok);
    ui -> passwdLine_2 -> clear();
    ui-> nameLine_2 -> clear();
}
